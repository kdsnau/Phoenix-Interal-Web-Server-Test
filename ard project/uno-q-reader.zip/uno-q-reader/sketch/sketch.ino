/*
 * Phoenix Door Reader — MCU (Arduino/Zephyr) side.
 *
 * Reads a card UID from the PN532 (I2C) and asks the Linux side to decide via
 * the RouterBridge: Bridge.call("check_access", uid).result(unlockMs). The Python
 * side does the HMAC + HTTP to the backend and returns unlock_ms (>0 = grant).
 * This half just does the real-time I/O: NFC read + relay/LED/buzzer.
 *
 * Wiring (Uno Q): PN532 on I2C -> dedicated SDA/SCL pins (NOT A4/A5), IRQ->D2,
 * RST->D3. Relay D7, green LED D5, red LED D6, buzzer D8.
 */
#include "Arduino_RouterBridge.h"
#include <Wire.h>
#include <Adafruit_PN532.h>

#define PN532_IRQ    2
#define PN532_RESET  3
#define PIN_RELAY    7
#define LED_GREEN    5
#define LED_RED      6
#define PIN_BUZZER   8
#define UID_MAX      7

Adafruit_PN532 nfc(PN532_IRQ, PN532_RESET); // I2C

void setup() {
  Serial.begin(9600);
  pinMode(PIN_RELAY, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_RED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_RELAY, LOW);

  Bridge.begin();

  nfc.begin();
  if (!nfc.getFirmwareVersion()) {
    // PN532 not found — blink red forever (check I2C wiring + DIP=I2C).
    while (1) { digitalWrite(LED_RED, HIGH); delay(200); digitalWrite(LED_RED, LOW); delay(200); }
  }
  nfc.SAMConfig();
  Serial.println("Reader ready.");
}

void loop() {
  uint8_t uid[UID_MAX];
  uint8_t uidLen = 0;
  if (!nfc.readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLen, 250)) return;

  char hex[2 * UID_MAX + 1];
  toHex(uid, uidLen, hex);
  Serial.print("Tag: "); Serial.println(hex);

  // Ask the Linux side to validate over the network. Blocks until it answers.
  int unlockMs = 0;
  Bridge.call("check_access", hex).result(unlockMs);

  if (unlockMs > 0) {
    digitalWrite(LED_GREEN, HIGH);
    beep(1200, 120);
    digitalWrite(PIN_RELAY, HIGH);
    unsigned long t0 = millis();
    while (millis() - t0 < (unsigned long)unlockMs) { /* held open */ }
    digitalWrite(PIN_RELAY, LOW);
    digitalWrite(LED_GREEN, LOW);
  } else {
    digitalWrite(LED_RED, HIGH);
    beep(300, 400);
    digitalWrite(LED_RED, LOW);
  }
  delay(1200); // debounce
}

void beep(unsigned int freq, unsigned int ms) {
  tone(PIN_BUZZER, freq, ms);
  delay(ms);
  noTone(PIN_BUZZER);
}

void toHex(const uint8_t *b, uint8_t len, char *out) {
  const char *h = "0123456789ABCDEF";
  for (uint8_t i = 0; i < len; i++) { out[i * 2] = h[b[i] >> 4]; out[i * 2 + 1] = h[b[i] & 0x0F]; }
  out[len * 2] = 0;
}
